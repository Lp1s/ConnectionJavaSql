/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soundscapeproject;

/**
 *
 * @author nikii
 */
import GUI.Index;
public class SoundScapeProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Index pnta = new Index();
       pnta.setVisible(true);
       pnta.setLocationRelativeTo(null);
    }
    
}
