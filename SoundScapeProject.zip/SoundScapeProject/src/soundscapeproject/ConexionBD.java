/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soundscapeproject;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
/**
 *
 * @author nikii
 */
public class ConexionBD {
    
    Connection conectar=null;
    public Connection conexion(){
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conectar=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/studiodb","root","");
            System.out.println("Conexion aceptada...");
        }catch (Exception e){
            System.out.println("mensaje de error"+e);
            JOptionPane.showMessageDialog(null,"No se pudo conectar");
            
        }
        return conectar;
    }
}
